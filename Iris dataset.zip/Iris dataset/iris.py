import pandas as pandas
import streamlit as st
import numpy as np
import joblib 
#Load model
model = joblib.load("iris_model.joblib")
#streamlit UI
st.title= ("Iris Flower Species Prediction")
st.write= ("Enter the flower measurments and predict the species")

#User input
sepal_length = st.number_input("Sepal length", min_value=0.0, max_value =10.0, value=5.0)
sepal_width = st.number_input("Sepal Width", min_value=0.0, max_value = 10.0, value = 3.0)
petal_length = st.number_input("Petal length", min_value=0.0, max_value= 10.0, value=1.0)
petal_width = st.number_input("Petal width", min_value=0.0, max_value= 10.0, value=0.1)
#predict button
if st.button("Predict"):
    features = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
    prediction = model.predict(features)[0]
    
    iris_classes = ['Setosa', 'Versicolor','Virginca']
    st.success(f"Predicted Flower: **{iris_classes[prediction]}**")
    
